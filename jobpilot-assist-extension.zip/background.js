// JobPilot Assist — service worker.
//
// Owns the network calls so the popup and content script stay simple: drafting
// a cover letter against the deployed JobPilot API, and caching the profile the
// user fills in for autofill.

const API_BASE = 'https://ai-job-application-agent-pi.vercel.app';

async function draftLetter(job, profile) {
  const resume = {
    name: profile.name || '',
    email: profile.email || '',
    phone: profile.phone || '',
    skills: (profile.skills || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    experience: [],
    education: [],
    summary: profile.summary || '',
  };

  const response = await fetch(`${API_BASE}/api/gemini`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'generate-cover-letter', data: { resume, job } }),
  });

  if (!response.ok) {
    return { ok: false, error: `JobPilot API returned HTTP ${response.status}` };
  }

  const body = await response.json();
  if (!body?.success || !body?.data?.body) {
    return { ok: false, error: body?.error || 'The AI returned no letter.' };
  }
  return {
    ok: true,
    letter: body.data.body,
    subject: body.data.subject || `Application for ${job.title} at ${job.company}`,
  };
}

async function answerQuestions(questions, job, profile) {
  const response = await fetch(`${API_BASE}/api/gemini`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'answer-questions', data: { profile, questions, job } }),
  });
  if (!response.ok) return { ok: false, error: `JobPilot API returned HTTP ${response.status}` };
  const body = await response.json();
  if (!body?.success) return { ok: false, error: body?.error || 'The AI returned no answers.' };
  return { ok: true, answers: body.data?.answers || [] };
}

async function polishAnswer(question, draft, profile) {
  const response = await fetch(`${API_BASE}/api/gemini`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'polish-answer', data: { question, draft, profile } }),
  });
  if (!response.ok) return { ok: false, error: `JobPilot API returned HTTP ${response.status}` };
  const body = await response.json();
  if (!body?.success) return { ok: false, error: body?.error || 'Could not polish.' };
  return { ok: true, ...body.data };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'POLISH_ANSWER') {
    (async () => {
      try {
        sendResponse(await polishAnswer(message.question || '', message.draft || '', message.profile || {}));
      } catch (error) {
        sendResponse({ ok: false, error: error?.message || String(error) });
      }
    })();
    return true;
  }
  if (message?.type === 'ANSWER_QUESTIONS') {
    (async () => {
      try {
        const { profile = {} } = await chrome.storage.local.get('profile');
        sendResponse(await answerQuestions(message.questions || [], message.job || {}, profile));
      } catch (error) {
        sendResponse({ ok: false, error: error?.message || String(error) });
      }
    })();
    return true;
  }
  if (message?.type === 'DRAFT_LETTER') {
    (async () => {
      try {
        const { profile = {} } = await chrome.storage.local.get('profile');
        sendResponse(await draftLetter(message.job || {}, profile));
      } catch (error) {
        sendResponse({ ok: false, error: error?.message || String(error) });
      }
    })();
    return true; // keep the channel open for the async reply
  }
  return false;
});
